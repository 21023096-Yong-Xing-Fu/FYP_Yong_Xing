/**
 * I declare that this code was written by me, 21024433. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * Student Name: Ryan Pee
 * Student ID: 21024433
 * Class: E63C
 * Date created: 2023-May-15 3:12:27 pm 

 */
package e62c.yunke.ga02;

import java.util.Arrays;
import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

public class AccountDetails implements UserDetails {
	
private Accounts accounts;
	
	public AccountDetails(Accounts accounts) {
		this.accounts = accounts;
    }
	
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		SimpleGrantedAuthority authority = new SimpleGrantedAuthority(accounts.getRole());
		return Arrays.asList(authority);
	}
	
	@Override
	public String getPassword() {
		return accounts.getPassword();
	}
	
	@Override
	public String getUsername() {
		return accounts.getUsername();
	}
	
	
	@Override
	public boolean isAccountNonExpired() {
		return true;
	}
	
	@Override
	public boolean isAccountNonLocked() {
		return true;
	}
	
	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}
	
	@Override
	public boolean isEnabled() {
		return true;
	}
	
	public Accounts getAccount() {
		return accounts;
	}
	
	public void setAccount(Accounts accounts) {
		this.accounts = accounts;
	}

}
