package e62c.yunke.ga02;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class ChangePasswordForm {
	@NotNull
	@NotEmpty(message = "Current Password cannot be empty!")
	private String currentPassword;

	@NotNull
	@NotEmpty(message = "New Password cannot be empty!")
	private String newPassword;

	@NotNull
	@NotEmpty(message = "Confirm Password cannot be empty!")
	private String confirmPassword;

	// Custom validation method to ensure new password is not the same as the
	// current password
	public boolean isNewPasswordValid() {
		return !newPassword.equals(currentPassword);
	}

	public String getCurrentPassword() {
		return currentPassword;
	}

	public void setCurrentPassword(String currentPassword) {
		this.currentPassword = currentPassword;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
}
