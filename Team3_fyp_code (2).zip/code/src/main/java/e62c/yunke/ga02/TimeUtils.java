//package e62c.yunke.ga02;
//
//import java.sql.Time;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//
//public class TimeUtils {
//    private static final SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
//
//    public static Time parseTime(String timeString) throws ParseException {
//        java.util.Date date = timeFormat.parse(timeString);
//        return new Time(date.getTime());
//    }
//}



