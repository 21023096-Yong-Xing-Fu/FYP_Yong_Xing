/**
 * 
 * I declare that this code was written by me, 21023096. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Student Name: Yong Xing Fu
 * Student ID: 21023096
 * Class: E63C
 * Date created: 2023-May-01 8:01:09 pm 
 * 
 */

package e62c.yunke.ga02;


import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

@Controller
public class TimeSheetController {
	@Autowired
	private TimeSheetRepository TSRepository;

	@Autowired
	private ProgramRunRepository programRunRepository;

	
	@Autowired
	private ProgramRepository programRepository;
	
	@Autowired
	private AccountRepository accountRepository;
	
	@GetMapping("/timesheet")
	public String viewTimeSheet(Model model,Principal principal,@RequestParam(value = "verification", required = false) String verification,
            @RequestParam(value = "dateType", required = false) String dateType) { 
		List<TimeSheet> listOfTimesheet= TSRepository.findAll();

		model.addAttribute("listOfTimesheet", listOfTimesheet);
	  
		return "view_timesheet";
		
	}

	@PostMapping("/timesheet/save")
	public String saveTimeSheet(@Valid TimeSheet timesheet, BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			return "add_timesheet";
		}

		TSRepository.save(timesheet);
		// save is an API from JPA to save the category fields
		// in the category table in the database
		return "redirect:/timesheet";
	}

	@GetMapping("/timesheet/add")
	public String addTimeSheet(Model model) {
		model.addAttribute("timesheet", new TimeSheet());
		return "add_timesheet";
	}

	@PostMapping("/ts/save")
	public String saveTS(@Valid TimeSheet timesheet, BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			return "add_ts";
		}

		TSRepository.save(timesheet);
		// save is an API from JPA to save the category fields
		// in the category table in the database
		return "redirect:/timesheet";
	}

	@GetMapping("/ts/add")
	public String addTS(Model model) {
		model.addAttribute("timesheet", new TimeSheet());
		return "add_ts";
	}

	@GetMapping("/timesheet_report")
	public String reportTS(Model model) {
		List<TimeSheet> listOfTimesheet = TSRepository.findAll();
		// findAll is an API provided by JpaRepository which is similar to
		// SELECT * FROM Timesheet;

		model.addAttribute("listOfTimesheet", listOfTimesheet);
		return "timesheet_report";
	}

//	@GetMapping("/timesheet/{id}")
//	public String viewSingleTS(@PathVariable("id") Integer id, Model model) {
//		TimeSheet timesheet = TSRepository.getById(id);
//		// getById is = Select * from Product where id = id
//
//		model.addAttribute("timesheet", timesheet);
//		List<ProgramRun> listProgramRuns = programRunRepository.findAll();
//		//List<ProgramRun> listProgramRuns = programRunRepository.findAll();
//
//		model.addAttribute("listProgramRuns", listProgramRuns);
//
//		// if (userRole.equals("ROLE_ADMIN")) {
//		// List<Accounts> listAccounts = accountRepository.findAll();
//		// model.addAttribute("listAccounts", listAccounts);
//		// } else if (userRole.equals("ROLE_TRAINER")) {
//		// // Retrieve the currently logged in trainer's account
//		// String username = authentication.getName();
//
//		// model.addAttribute("listAccounts",
//		// Collections.singletonList(trainerAccount));
//		// }
//
//		return "view_single_item";
//	}
	
	@GetMapping("/timesheet/{id}")
	public String viewSingleTS(@PathVariable("id") Integer id, Model model, Principal principal) {
	    

	    TimeSheet timesheet = TSRepository.getById(id);
	    // Here, you should also fetch the user-specific timesheet based on the username
	    // For example: TimeSheet timesheet = timeSheetRepository.findByUsernameAndId(username, id);

	    model.addAttribute("timesheet", timesheet);
	    

	    List<ProgramRun> listProgramRuns = programRunRepository.findAllByAccountUsername(timesheet.getName());
	    model.addAttribute("listProgramRuns", listProgramRuns);
	    

	    // Add other necessary code to handle user roles and their own data

	    return "view_single_item";
	}


	@GetMapping("/timesheet/edit/{id}")
	public String editTimeSheet(@PathVariable("id") Integer id, Model model) {
		TimeSheet timesheet = TSRepository.getById(id);
		model.addAttribute("timesheet", timesheet);

		return "edit_timesheet";
	}

	@PostMapping("/timesheet/edit/{id}")
	public String saveUpdatedTimeSheet(@PathVariable("id") Integer id, TimeSheet timesheet) {
		TSRepository.save(timesheet);
		return "redirect:/timesheet";
	}

	@GetMapping("/timesheet/delete/{id}")
	public String deleteTimeSheet(@PathVariable("id") Integer id) {
		TSRepository.deleteById(id);
		return "redirect:/timesheet";
	}

	
//	@GetMapping("/timesheetReport/{id}")
//    public String getTimesheetReport(@PathVariable("id") Integer id, Model model) {
//        // Retrieve timesheet data for the specific username from the database
//		TimeSheet timesheet = TSRepository.getById(id);
//		model.addAttribute("timesheet", timesheet);
//		
//        List<ProgramRun> listProgramRuns = programRunRepository.findAllByAccountUsername(timesheet.getName());
//        
//        // Pass the timesheet data and username to the view
//        model.addAttribute("listProgramRuns", listProgramRuns);
//
//        ;
//        // Return the view name for timesheet_report.html
//        return "timesheet_report";
//    }
	
	// Sample modification in TimesheetController.java
	@GetMapping("/timesheetReport/{id}")
	public String getTimesheetReport(@PathVariable("id") Integer id, Model model) {
		TimeSheet timesheet = TSRepository.getById(id);
	    // Assuming you have a method to fetch the trainer's timesheet data by ID from the database
		List<ProgramRun> listProgramRuns = programRunRepository.findAllByAccountUsername(timesheet.getName());
	    
	    if (timesheet == null) {
	        // Handle the case where the trainer with the specified ID is not found
	        return "redirect:/timesheet"; // You can redirect to an error page or handle it accordingly
	    }

	    // Pass the trainer's data to the view
	    model.addAttribute("timesheet", timesheet);
	    model.addAttribute("listProgramRuns", listProgramRuns);

	    return "timesheet_report";
	}

	
	@GetMapping("/timesheet/chart-data")
	@ResponseBody
	public ResponseEntity<String> getChartData() {
	    List<ProgramRun> listProgramRuns = programRunRepository.findAll();
	    List<Programs> listPrograms = programRepository.findAll();

	    // Extract the required data for the charts
	    List<String> programNames = new ArrayList<>();
	    List<Integer> programCounts = new ArrayList<>();
	    List<Double> amountsEarned = new ArrayList<>();
	    List<String> trainerName = new ArrayList<>();

	    for (ProgramRun cat : listProgramRuns) {
	     
	        programCounts.add(countProgramOccurrences(cat.getProgram(), listProgramRuns));
	        amountsEarned.add(cat.getAmount());
	        trainerName.add(cat.getTrainerName());
	    }
	    
	    for (Programs cat : listPrograms) {
	        programNames.add(cat.getProgramName());
	       
	    }

	    // Prepare the JSON data
	    Gson gson = new Gson();
	    JsonObject data = new JsonObject();
	    JsonArray programNamesArray = gson.toJsonTree(programNames).getAsJsonArray();
	    JsonArray programCountsArray = gson.toJsonTree(programCounts).getAsJsonArray();
	    JsonArray amountsEarnedArray = gson.toJsonTree(amountsEarned).getAsJsonArray();
	    JsonArray trainerNameArray = gson.toJsonTree(trainerName).getAsJsonArray();
	    

	    data.add("programNames", programNamesArray);
	    data.add("programCounts", programCountsArray);
	    data.add("amountsEarned", amountsEarnedArray);
	    data.add("trainerName", trainerNameArray);
	    

	    return ResponseEntity.ok(data.toString());
	}

	private int countProgramOccurrences(Programs programs, List<ProgramRun> programRuns) {
	    int count = 0;
	    for (ProgramRun programRun : programRuns) {
	        if (programRun.getProgram().equals(programs)) {
	            count++;
	        }
	    }
	    return count;
	}

	/**
	 * @return the programRepository
	 */
	public ProgramRepository getProgramRepository() {
		return programRepository;
	}

	/**
	 * @param programRepository the programRepository to set
	 */
	public void setProgramRepository(ProgramRepository programRepository) {
		this.programRepository = programRepository;
	}


}
