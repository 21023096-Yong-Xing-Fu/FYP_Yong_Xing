/**
 * I declare that this code was written by me, 21024433. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * Student Name: Ryan Pee
 * Student ID: 21024433
 * Class: E63C
 * Date created: 2023-May-01 7:57:54 pm 

 */
package e62c.yunke.ga02;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountRepository extends JpaRepository<Accounts, Integer> {
	
	public Accounts findByUsername(String username);
 
	public Accounts findByEmail(String email);

	
	public Accounts findByResetToken(String resetToken);


}
