package e62c.yunke.ga02;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.Principal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityGraph;
import javax.persistence.EntityManager;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;



//import org.jfree.data.category.DefaultCategoryDataset;
//import org.springframework.ui.Model;


@Controller
public class ProgramRunController {

	@Autowired
	private ProgramRunRepository programRunRepository;
	
	@Autowired
	private ProgramRepository programRepository;
	
	@Autowired
	private AccountRepository accountRepository;
	
	@Autowired
	private JavaMailSender javaMailSender;
	
	//5/8
	@GetMapping("/programRuns")
	public String viewProgramRuns(Model model, Principal principal,
	                              @RequestParam(value = "verification", required = false) String verification,
	                              @RequestParam(value = "dateType", required = false) String dateType) {

	    String userRole = SecurityContextHolder.getContext().getAuthentication().getAuthorities().iterator().next().getAuthority();
	    List<ProgramRun> programRuns;

	    if (userRole.equals("ROLE_ADMIN")) {
	        programRuns = programRunRepository.findAll();
	    } else if (userRole.equals("ROLE_TRAINER")) {
	        String username = principal.getName();
	        Accounts trainerAccount = accountRepository.findByUsername(username);
	        programRuns = programRunRepository.findByAccount(trainerAccount);
	    } else {
	        // Handle other user roles or unauthorized access here if needed
	        return "error";
	    }

	    // Check if filtering by verification is requested
	    if (verification != null && !verification.isEmpty()) {
	        programRuns = programRuns.stream()
	                .filter(run -> run.getVerify().equalsIgnoreCase(verification))
	                .collect(Collectors.toList());
	    }

	    // Check if filtering by date is requested
	    if (dateType != null && !dateType.isEmpty()) {
	        LocalDate today = LocalDate.now();
	        if (dateType.equals("upcoming")) {
	            programRuns = programRuns.stream()
	                    .filter(run -> LocalDate.parse(run.getRunDate()).isAfter(today))
	                    .collect(Collectors.toList());
	        } else if (dateType.equals("past")) {
	            programRuns = programRuns.stream()
	                    .filter(run -> LocalDate.parse(run.getRunDate()).isBefore(today))
	                    .collect(Collectors.toList());
	        } else if (dateType.equals("today")) {
	            programRuns = programRuns.stream()
	                    .filter(run -> LocalDate.parse(run.getRunDate()).isEqual(today))
	                    .collect(Collectors.toList());
	        }
	    }
	    
	    //5/8 to retrieve sch 
	 // Add the list of schools to the model
	    List<String> schools = programRunRepository.findAllDistinctSchoolBy();
        model.addAttribute("schools", schools);

	    model.addAttribute("listProgramRuns", programRuns);
	    return "view_programRuns";
	}

	
	//5/8
	@GetMapping("/programRuns/add")
	public String addProgramRun(Model model) {
	    // Check the user's role
	    String userRole = SecurityContextHolder.getContext().getAuthentication().getAuthorities().iterator().next().getAuthority();

	    if (userRole.equals("ROLE_TRAINER")) {
	        // Users with ROLE_TRAINER can only view the input, not edit it
	        model.addAttribute("readonly", true);
	    } else {
	        // Users with other roles (including ROLE_ADMIN) can edit the input
	        model.addAttribute("readonly", false);
	    }

	    //new 29/6
	    List<Programs> progList = programRepository.findAll(); // Assuming you have a repository for Category
	    model.addAttribute("progList", progList);

	    //new 12/7
	    List<Accounts> accList = accountRepository.findAll(); // Assuming you have a repository for Category
	    model.addAttribute("accList", accList);

	    model.addAttribute("programRun", new ProgramRun());

	    return "adding_programRuns";
	}

	
	//19/7
	@PostMapping("/programRuns/save")
	public String saveProgramRun(@Valid ProgramRun programRun, BindingResult bindingResult, Model model) {
	    if (bindingResult.hasErrors()) {
	       // System.out.println(bindingResult.getFieldError());
	    	List<Programs> progList = programRepository.findAll();
	        model.addAttribute("progList", progList);
	        
	        List<Accounts> accList = accountRepository.findAll(); // Assuming you have a repository for Category
	        model.addAttribute("accList", accList);
	        
	        return "adding_programRuns";
	    }

	    double duration = programRun.getDuration();
	    double rate = programRun.getRate();
	    double transportAllowance = programRun.getTransportAllowance();
	    String trainerName = programRun.getTrainerName();
	    String runDate = programRun.getRunDate();
	    
	    //6/8 to check prevent clashing 
	    Principal principal = SecurityContextHolder.getContext().getAuthentication();
	    String username = principal.getName();
	    Accounts trainerAccount = accountRepository.findByUsername(username);
	    
        List<ProgramRun> existingBookings = programRunRepository.findByAccountUsernameAndRunDate(username, programRun.getRunDate());

        for (ProgramRun existingBooking : existingBookings) {
            if (areTimesClashing(existingBooking, programRun)) {
                bindingResult.rejectValue("runDate", "error.programRun", "This trainer already has a booking at the specified date and time.");
                return "adding_programRuns";
            }
        }

	    double amount = (duration * rate) + transportAllowance;
	    programRun.setAmount(amount);

	    programRunRepository.save(programRun);

	    // Send email
	    String subject = "BOOKING of Program Run Booking.";
	    String body = "Dear " + trainerAccount.getName() + ",\n"
	    		+ "We have posted a program for you to run.\n \n"
	    		+ "Your current status is still pending, we will update your booking CONFIRMATION soon."
	    		+ "The details of your Program Run are as follows.\n \n"
	    		+ "Date: " + programRun.getRunDate()
	    		+ "Program: " + programRun.getProgram().getProgramName() + "\n"
	            + "School: " + programRun.getSchool() + "\n"
	            + "Arrival Time: " + programRun.getArrivalTime() + "\n"
	            + "Departure Time: " + programRun.getDepartTime() + "\n"
	            + "Lesson Start: " + programRun.getLessonStart() + "\n"
	            + "Lesson Stop: " + programRun.getLessonStop() + "\n"
	            + "Duration: " + programRun.getDuration() + " hours\n"
	            + "Rate: $" + programRun.getRate() + " per hour\n"
	            + "Transport Allowance: $" + programRun.getTransportAllowance() + "\n"
	            + "Booking Status: " + programRun.getVerify() + "\n"
	            + "Total Amount: $" + programRun.getAmount() + "\n"
	            + "Remarks: " + programRun.getRemarks() + "\n\n"
	            + ""
	            + "Feel free to reach out to us should you require assistance.\n" 
	            + "***This is an auto generated email, please do not reply.***";
	    String to = trainerAccount.getEmail();
	    sendEmail(to, subject, body);

	    return "redirect:/programRuns";
	}
	
	//6/8 prevent clashign 
	private boolean areTimesClashing(ProgramRun booking1, ProgramRun booking2) {
        String arrivalTime1 = booking1.getArrivalTime();
        String departTime1 = booking1.getDepartTime();
        String arrivalTime2 = booking2.getArrivalTime();
        String departTime2 = booking2.getDepartTime();

        // Convert time strings to LocalTime objects for easy comparison
        LocalTime time1Arrival = LocalTime.parse(arrivalTime1);
        LocalTime time1Departure = LocalTime.parse(departTime1);
        LocalTime time2Arrival = LocalTime.parse(arrivalTime2);
        LocalTime time2Departure = LocalTime.parse(departTime2);

        // Check for clashes in time ranges
        if ((time1Arrival.isBefore(time2Departure) && time1Departure.isAfter(time2Arrival)) ||
                (time2Arrival.isBefore(time1Departure) && time2Departure.isAfter(time1Arrival))) {
            return true; // Clashing times
        }

        return false; // No clashes
    }

	private void sendEmail(String to, String subject, String body) {
	    SimpleMailMessage msg = new SimpleMailMessage();
	    msg.setTo(to);
	    msg.setSubject(subject);
	    msg.setText(body);

	    javaMailSender.send(msg);
	}

	//6/8 ps
	@GetMapping("/programRuns/edit/{id}")
	public String editProgramRun(@PathVariable("id") Integer id, Model model) {
	    // Fetch the existing ProgramRun object from the database using the ID
	    ProgramRun programRun = programRunRepository.findById(id).orElse(null);

	    if (programRun == null) {
	        // Handle the case where the ProgramRun with the given ID is not found
	        return "redirect:/programRuns";
	    }

	    model.addAttribute("programRun", programRun);

	    //new 29/6
	    List<Programs> progList = programRepository.findAll(); // Assuming you have a repository for Category
	    model.addAttribute("progList", progList);

	    return "edit_programRun";
	}

	
	//6/8 ps
	@PostMapping("/programRuns/edit/{id}")
	public String saveUpdatedProgramRun(@Valid ProgramRun programRun, @PathVariable("id") Integer programRunId, BindingResult bindingResult) {
	    if (bindingResult.hasErrors()) {
	        return "edit_programRun";
	    }

	    // Fetch the existing ProgramRun object from the database
	    ProgramRun existingProgramRun = programRunRepository.getById(programRunId);

	    // Check for edited fields and build the editedFieldsMessage
	    StringBuilder editedFieldsMessage = new StringBuilder("Information updated:\n");
	    
	    if (!existingProgramRun.getProgram().equals(programRun.getProgram())) {
	        editedFieldsMessage.append("- Program\n");
	        existingProgramRun.setProgram(programRun.getProgram());
	    }
	    if (!existingProgramRun.getSchool().equals(programRun.getSchool())) {
	        editedFieldsMessage.append("- School\n");
	        existingProgramRun.setSchool(programRun.getSchool());
	    }
	    if (existingProgramRun.getDuration() != programRun.getDuration()) {
	        editedFieldsMessage.append("- Duration\n");
	        existingProgramRun.setDuration(programRun.getDuration());
	    }
	    if (existingProgramRun.getRate() != programRun.getRate()) {
	        editedFieldsMessage.append("- Rate\n");
	        existingProgramRun.setRate(programRun.getRate());
	    }
	    if (existingProgramRun.getTransportAllowance() != programRun.getTransportAllowance()) {
	        editedFieldsMessage.append("- Transport Allowance\n");
	        existingProgramRun.setTransportAllowance(programRun.getTransportAllowance());
	    }
	    if (!existingProgramRun.getRemarks().equals(programRun.getRemarks())) {
	        editedFieldsMessage.append("- Remarks\n");
	        existingProgramRun.setRemarks(programRun.getRemarks());
	    }
	    if (!existingProgramRun.getVerify().equals(programRun.getVerify())) {
	        editedFieldsMessage.append("- Verify\n");
	        existingProgramRun.setVerify(programRun.getVerify());
	    }
	    if (!existingProgramRun.getRunDate().equals(programRun.getRunDate())) {
	        editedFieldsMessage.append("- Run Date\n");
	        existingProgramRun.setRunDate(programRun.getRunDate());
	    }

	    if (!existingProgramRun.getArrivalTime().equals(programRun.getArrivalTime())) {
	        editedFieldsMessage.append("- Arrival Time\n");
	        existingProgramRun.setArrivalTime(programRun.getArrivalTime());
	    }

	    if (!existingProgramRun.getDepartTime().equals(programRun.getDepartTime())) {
	        editedFieldsMessage.append("- Departure Time\n");
	        existingProgramRun.setDepartTime(programRun.getDepartTime());
	    }

	    if (!existingProgramRun.getLessonStart().equals(programRun.getLessonStart())) {
	        editedFieldsMessage.append("- Lesson Start\n");
	        existingProgramRun.setLessonStart(programRun.getLessonStart());
	    }

	    if (!existingProgramRun.getLessonStop().equals(programRun.getLessonStop())) {
	        editedFieldsMessage.append("- Lesson Stop\n");
	        existingProgramRun.setLessonStop(programRun.getLessonStop());
	    }
	    
	    Principal principal = SecurityContextHolder.getContext().getAuthentication();
	    String username = principal.getName();
	    Accounts trainerAccount = accountRepository.findByUsername(username);

	    //new
	    // Retrieve existing bookings for the same trainer and run date
	    List<ProgramRun> existingBookings = programRunRepository.findByAccountUsernameAndRunDate(username, programRun.getRunDate());
	    
	    for (ProgramRun existingBooking : existingBookings) {
	        if (existingBooking.getProgram_run_id() != programRunId && areTimesClashing(existingBooking, programRun)) {
	            bindingResult.rejectValue("runDate", "error.programRun", "This trainer already has a booking at the specified date and time.");
	            return "edit_programRun";
	        }
	    }
  

	    // Save the updated ProgramRun object back to the database
	    programRunRepository.save(existingProgramRun);
	    
	    String subject = "UPDATE of Program Run Booking.";
	    String body = "Dear " + trainerAccount.getName() + ",\n"
	            + "We have updated the following details of your Program Run:\n\n"
	            + editedFieldsMessage.toString() // Include edited fields in the email body
	            + "\nDate: " + programRun.getRunDate() + "\n"
	            + "Program: " + existingProgramRun.getProgram().getProgramName() + "\n"
	            + "School: " + existingProgramRun.getSchool() + "\n"
	            + "Arrival Time: " + existingProgramRun.getArrivalTime() + "\n"
	            + "Departure Time: " + existingProgramRun.getDepartTime() + "\n"
	            + "Lesson Start: " + existingProgramRun.getLessonStart() + "\n"
	            + "Lesson Stop: " + existingProgramRun.getLessonStop() + "\n"
	            + "Duration: " + existingProgramRun.getDuration() + " hours\n"
	            + "Rate: $" + existingProgramRun.getRate() + " per hour\n"
	            + "Transport Allowance: $" + existingProgramRun.getTransportAllowance() + "\n"
	            + "Booking Status: " + programRun.getVerify() + "\n"
	            + "Remarks: " + existingProgramRun.getRemarks() + "\n\n"
	            + "Your BOOKING status is back to Pending, please wait for admin to update the booking status for confirmation.\n"
	            + "Feel free to reach out to us should you require assistance.\n" 
	            + "***This is an auto-generated email, please do not reply.***";
	    
	    String to = trainerAccount.getEmail();
	    sendEmail(to, subject, body);

	    return "redirect:/programRuns";
	}


	@GetMapping("/programRuns/delete/{id}")
	public String deleteProgramRun(@PathVariable("id")Integer id) {
		
		// Fetch the ProgramRun object to access its details for the email
	    ProgramRun programRun = programRunRepository.findById(id).orElse(null);
	    if (programRun == null) {
	        // Handle the case where the ProgramRun with the given id doesn't exist
	        // You can return an error page or redirect to a relevant page
	        return "redirect:/programRuns";
	    }

		programRunRepository.deleteById(id);
		
		// Retrieve the trainer's account using the Principal object
	    Principal principal = SecurityContextHolder.getContext().getAuthentication();
	    String username = principal.getName();
	    Accounts trainerAccount = accountRepository.findByUsername(username);

	    // Send email
	    String subject = "CANCELLATION of Program Run Booking.";
	    String body = "We are sorry that your Program Run is removed from our system.\n"
	    		+ "Details of CANCELLED program run are as follows:\n \n"
	    		+ "Date: " + programRun.getRunDate() + "\n"
	    		+ "Program: " + programRun.getProgram().getProgramName() + "\n"
	            + "School: " + programRun.getSchool() + "\n"
	            + "Arrival Time: " + programRun.getArrivalTime() + "\n"
	            + "Departure Time: " + programRun.getDepartTime() + "\n\n\n"
	            + ""
	            + "Feel free to reach out to us should you require assistance.\n" 
	            + "***This is an auto generated email, please do not reply.***";
	    String to = trainerAccount.getEmail();
	    sendEmail(to, subject, body);

		return "redirect:/programRuns";
	}
	
	@GetMapping("/programRuns/report/rate")
    public String generateRateReport(@RequestParam(required = false) String selectedTrainer, Model model) {
        List<ProgramRun> programRuns;
        List<Accounts> trainers = accountRepository.findAll();


        if (selectedTrainer != null) {
            // Filter by selected trainer
            programRuns = programRunRepository.findAllByAccountUsername(selectedTrainer);
        } else {
            programRuns = programRunRepository.findAll();
        }

        // Convert ProgramRun objects to ProgramRunJson objects
        List<ProgramRunJson> programRunsJson = programRuns.stream()
                .map(ProgramRunJson::new)
                .collect(Collectors.toList());

        // Convert the list of ProgramRunJson objects to JSON using Gson
        Gson gson = new Gson();
        String programRunsJsonStr = gson.toJson(programRunsJson);
        model.addAttribute("programRunsJson", programRunsJsonStr);
        model.addAttribute("trainers", trainers);

        return "programRunRateReport";
    }
	
	@GetMapping("/programRuns/report/duration")
    public String generateDurationReport(@RequestParam(required = false) String selectedTrainer, Model model) {
        List<ProgramRun> programRuns;
        List<Accounts> trainers = accountRepository.findAll();


        if (selectedTrainer != null) {
            // Filter by selected trainer
            programRuns = programRunRepository.findAllByAccountUsername(selectedTrainer);
        } else {
            programRuns = programRunRepository.findAll();
        }

        // Convert ProgramRun objects to ProgramRunJson objects
        List<ProgramRunJson> programRunsJson = programRuns.stream()
                .map(ProgramRunJson::new)
                .collect(Collectors.toList());

        // Convert the list of ProgramRunJson objects to JSON using Gson
        Gson gson = new Gson();
        String programRunsJsonStr = gson.toJson(programRunsJson);
        model.addAttribute("programRunsJson", programRunsJsonStr);
        model.addAttribute("trainers", trainers);

        return "programRunDurationReport";
    }
	

	@GetMapping("/api/program-schedule")
    public ResponseEntity<List<ProgramRun>> getProgramScheduleData() {
        List<ProgramRun> programRuns = programRunRepository.findAll();
        return ResponseEntity.ok(programRuns);
    }
	
	@GetMapping("/calendar")
    public String viewProgramRunCalendar(Model model) {
        // Fetch the list of ProgramRuns from the repository
        List<ProgramRun> programRuns = programRunRepository.findAll();

        // Add the list to the model attribute
        model.addAttribute("listProgramRuns", programRuns);

        // Return the calendar.html template
        return "calendar";
    }
	

}
