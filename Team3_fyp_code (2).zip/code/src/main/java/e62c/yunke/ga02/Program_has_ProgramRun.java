/**
 * 
 * I declare that this code was written by me, 21023327. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Student Name: Liu yuexiao
 * Student ID: 21023327
 * Class: E63C
 * Date created: 2023-May-01 8:24:31 pm 
 * 
 */

package e62c.yunke.ga02;

/**
 * @author 21023327
 *
 */
public class Program_has_ProgramRun {

}
