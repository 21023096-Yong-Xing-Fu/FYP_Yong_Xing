package e62c.yunke.ga02;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface ProgramRunRepository extends JpaRepository<ProgramRun, Integer>{
	//5/7
	public List<ProgramRun> findByAccount_Id(int id);
	public List<ProgramRun> findByTrainerContact(int trainerContact);

	//3/8
	public List<ProgramRun> findByAccount(Accounts account);
	
	//4/8
	List<ProgramRun> findAllByAccountUsername(String username);
	List<ProgramRun> findAllByTrainerName(String name);
	
	//5/8
	 @Query("SELECT DISTINCT p.school FROM ProgramRun p")
	 List<String> findAllDistinctSchoolBy();
	 
	 //6/8 to prevent clashing 
	 List<ProgramRun> findByAccountUsernameAndRunDate(String username, String runDate);
	
	

}

