package e62c.yunke.ga02;

//for generating report
public class ProgramRunJson {
    private int program_run_id;
    private int trainerContact;
    private String trainerEmail;
    private String trainerName;
    private String school;
    private double duration;
    private double rate;
    private double transportAllowance;
    private double amount;
    private String verify;
    private String remarks;
    private String runDate;
    public int getProgram_run_id() {
		return program_run_id;
	}

	public void setProgram_run_id(int program_run_id) {
		this.program_run_id = program_run_id;
	}

	public int getTrainerContact() {
		return trainerContact;
	}

	public void setTrainerContact(int trainerContact) {
		this.trainerContact = trainerContact;
	}

	public String getTrainerEmail() {
		return trainerEmail;
	}

	public void setTrainerEmail(String trainerEmail) {
		this.trainerEmail = trainerEmail;
	}

	public String getTrainerName() {
		return trainerName;
	}

	public void setTrainerName(String trainerName) {
		this.trainerName = trainerName;
	}

	public String getSchool() {
		return school;
	}

	public void setSchool(String school) {
		this.school = school;
	}

	public double getDuration() {
		return duration;
	}

	public void setDuration(double duration) {
		this.duration = duration;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public double getTransportAllowance() {
		return transportAllowance;
	}

	public void setTransportAllowance(double transportAllowance) {
		this.transportAllowance = transportAllowance;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getVerify() {
		return verify;
	}

	public void setVerify(String verify) {
		this.verify = verify;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getRunDate() {
		return runDate;
	}

	public void setRunDate(String runDate) {
		this.runDate = runDate;
	}

	public String getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public String getDepartTime() {
		return departTime;
	}

	public void setDepartTime(String departTime) {
		this.departTime = departTime;
	}

	public String getLessonStart() {
		return lessonStart;
	}

	public void setLessonStart(String lessonStart) {
		this.lessonStart = lessonStart;
	}

	public String getLessonStop() {
		return lessonStop;
	}

	public void setLessonStop(String lessonStop) {
		this.lessonStop = lessonStop;
	}

	private String arrivalTime;
    private String departTime;
    private String lessonStart;
    private String lessonStop;

    // Add getters and setters for all the fields
    // ...

    // Constructor
    public ProgramRunJson(ProgramRun programRun) {
        this.program_run_id = programRun.getProgram_run_id();
//        this.trainerContact = programRun.getTrainerContact();
//        this.trainerEmail = programRun.getTrainerEmail();
//        this.trainerName = programRun.getTrainerName();
        this.school = programRun.getSchool();
        this.duration = programRun.getDuration();
        this.rate = programRun.getRate();
        this.transportAllowance = programRun.getTransportAllowance();
        this.amount = programRun.getAmount();
        this.verify = programRun.getVerify();
        this.remarks = programRun.getRemarks();
        this.runDate = programRun.getRunDate();
        this.arrivalTime = programRun.getArrivalTime();
        this.departTime = programRun.getDepartTime();
        this.lessonStart = programRun.getLessonStart();
        this.lessonStop = programRun.getLessonStop();
    }

    // Add other methods if needed
    // ...
}

