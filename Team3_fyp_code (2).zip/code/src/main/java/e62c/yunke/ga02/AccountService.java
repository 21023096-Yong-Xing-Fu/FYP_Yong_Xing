/**
 * I declare that this code was written by me, 21024433. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * Student Name: Ryan Pee
 * Student ID: 21024433
 * Class: E63C
 * Date created: 2023-May-17 1:42:34 pm 

 */
package e62c.yunke.ga02;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccountService {

	@Autowired
	private AccountRepository accountRepository;

	public void saveAccount(Accounts accounts) {
		if (isUsernameExists(accounts.getUsername())) {
			throw new IllegalArgumentException("Username already exists");
		}

		if (isEmailExists(accounts.getEmail())) {
			throw new IllegalArgumentException("Email already exists");
		}

		// Save the account details to the database
		accountRepository.save(accounts);
	}

	public boolean isUsernameExists(String username) {
		// Check if the username already exists in the database
		Accounts existingAccount = accountRepository.findByUsername(username);
		return existingAccount != null;
	}

	public boolean isEmailExists(String email) {
		// Check if the email already exists in the database
		Accounts existingAccount = accountRepository.findByEmail(email);
		return existingAccount != null;
	}

	public List<Accounts> getAllAccounts() {
		return accountRepository.findAll();
	}
}
