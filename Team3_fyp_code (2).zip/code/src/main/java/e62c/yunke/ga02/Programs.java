/**
 * 
 * I declare that this code was written by me, 21023327. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Student Name: Liu yuexiao
 * Student ID: 21023327
 * Class: E63C
 * Date created: 2023-May-01 7:41:04 pm 
 * 
 */

package e62c.yunke.ga02;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


/**
 * @author 21023327
 *
 */
@Entity
public class Programs {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @NotNull
    @NotEmpty(message = "B-Program name cannot be empty!")
    @Size(min = 5, max = 50, message = "B-Program length must be between 5 and 50 characters!")
    private String programName;

    @NotNull
    @NotEmpty(message = "Description cannot be empty!")
    @Size(min = 5, max = 100, message = "Description length must be between 5 and 100 characters!")
    private String description;

    @NotNull(message = "Minimum age cannot be empty!")
    private Integer ageGroupMin;

    @NotNull(message = "Maximum age cannot be empty!")
    private Integer ageGroupMax;

    @NotNull(message = "Category cannot be empty!")
    @ManyToOne
    @JoinColumn(name = "category_id", nullable = false)
    private Categorys category;
	
	
	public Categorys getCategory() {
		return category;
	}
	public void setCategory(Categorys categorys) {
		this.category = categorys;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the programName
	 */
	public String getProgramName() {
		return programName;
	}
	/**
	 * @param programName the programName to set
	 */
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
//	public String getAgeGroup() {
//		return ageGroup;
//	}
//	public void setAgeGroup(String ageGroup) {
//		this.ageGroup = ageGroup;
//	}
	
	public Integer getAgeGroupMin() {
		return ageGroupMin;
	}

	public void setAgeGroupMin(Integer ageGroupMin) {
		this.ageGroupMin = ageGroupMin;
	}

	public Integer getAgeGroupMax() {
		return ageGroupMax;
	}

	public void setAgeGroupMax(Integer ageGroupMax) {
		this.ageGroupMax = ageGroupMax;
	}
	
}
	