
package e62c.yunke.ga02;

import java.sql.Date;
import java.sql.Time;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Length;


/**
 * @author 21020419
 *
 */
@Entity
public class ProgramRun {
	
	//29/6
	@ManyToOne
	@JoinColumn(name="account_id", nullable=true)
	private Accounts account;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="program_id", nullable=false) 
	private Programs program;
	
	@ManyToOne
	@JoinColumn(name="timesheet_id", nullable=true)
	private TimeSheet timesheet;
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int program_run_id;

	//@NotNull
	//@NotEmpty(message="Backend - Trainer contact cannot be empty!")
	//@Length(min=8, max = 8, message = "Trainer contact has to has 8 digits!")
	private int trainerContact;
	
	//@NotNull
	//@NotEmpty(message="Backend - Email is required.!")
	//@Size(min=15, max = 30, message = "Minimum 3 characters, maximum 30 charaters!")
	private String trainerEmail;
	
	//@NotNull
	//@NotEmpty(message="Backend - Trainer Name is required.!")
	//@Size(min=3, max = 15, message = "Minimum 3 characters, maximum 15 charaters!")
	private String trainerName;

	@NotNull
	//@NotEmpty(message="Backend - School is required.!")
	//@Size(min=3, max = 30, message = "Minimum 3 characters, maximum 30 charaters!")
	private String school; 
	
	@NotNull
	//@NotEmpty(message = "Backend - Duration is required!")
	//@Size(min = 1, max =24, message = "Minimum duration has to be above 0 and under 24 hours!")
	private double duration; 
	
	@NotNull
	//@NotEmpty(message = "Backend - Rate is required!")
	//@Size(min = 1, message = "Minimum rate has to be above 0!")
	private double rate;
	
	@NotNull
	//@Size(min = 1, message = "Transport Allowance has to be above 0!")
	private double transportAllowance; 
	
	@NotNull
	//@NotEmpty(message = "Backend - Amount is required!")
	//@Length(min = 1, message = "Amount has to be above 0!")
	private double amount; 
	
	@NotNull
	@NotEmpty(message = "Backend - Verification is required!")
	private String verify;
	 
	private String remarks; 
	
	@NotNull
	@NotEmpty(message = "Backend - Run Date is required!")
	private String runDate; 
	
	@NotNull
	@NotEmpty(message = "Backend - Arrival Time is required!")
	private String arrivalTime; 
	
	@NotNull
	@NotEmpty(message = "Backend - Departure Time is required!")
	private String departTime;
	
	@NotNull
	@NotEmpty(message = "Backend - Lesson start is required!")
	private String lessonStart;
	
	@NotNull
	@NotEmpty(message = "Backend - Lesson stop is required!")
	private String lessonStop;


	public Accounts getAccount() {
		return account;
	}

	public void setAccount(Accounts account) {
		this.account = account;
	}

	public String getSchool() {
		return school;
	}

	public void setSchool(String school) {
		this.school = school;
	}

	public double getDuration() {
		return duration;
	}

	public void setDuration(double duration) {
		this.duration = duration;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public double getTransportAllowance() {
		return transportAllowance;
	}

	public void setTransportAllowance(double transportAllowance) {
		this.transportAllowance = transportAllowance;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getVerify() {
		return verify;
	}

	public void setVerify(String verify) {
		this.verify = verify;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public int getProgram_run_id() {
		return program_run_id;
	}

	public void setProgram_run_id(int program_run_id) {
		this.program_run_id = program_run_id;
	}


	public String getRunDate() {
		return runDate;
	}

	public void setRunDate(String runDate) {
		this.runDate = runDate;
	}

	public String getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public String getDepartTime() {
		return departTime;
	}

	public void setDepartTime(String departTime) {
		this.departTime = departTime;
	}

	public String getLessonStart() {
		return lessonStart;
	}

	public void setLessonStart(String lessonStart) {
		this.lessonStart = lessonStart;
	}

	public String getLessonStop() {
		return lessonStop;
	}

	public void setLessonStop(String lessonStop) {
		this.lessonStop = lessonStop;
	}

	public Programs getProgram() {
		return program;
	}

	public void setProgram(Programs program) {
		this.program = program;
	}

	public int getTrainerContact() {
		return trainerContact;
	}

	public void setTrainerContact(int trainerContact) {
		this.trainerContact = trainerContact;
	}

	public String getTrainerEmail() {
		return trainerEmail;
	}

	public void setTrainerEmail(String trainerEmail) {
		this.trainerEmail = trainerEmail;
	}

	public String getTrainerName() {
		return trainerName;
	}

	public void setTrainerName(String trainerName) {
		this.trainerName = trainerName;
	}

	
	
}