/**
 * 
 * I declare that this code was written by me, 21023096. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Student Name: Yong Xing Fu
 * Student ID: 21023096
 * Class: E63C
 * Date created: 2023-May-01 8:00:43 pm 
 * 
 */


package e62c.yunke.ga02;



import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

//@Id specifies the member int id as the primary key
//@Generated value - will auto generate the id value
@Entity
public class TimeSheet {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	
	
	
	private int id;
	/**
	 * @return the account
	 */
	public Accounts getAccount() {
		return account;
	}
	/**
	 * @param account the account to set
	 */
	public void setAccount(Accounts account) {
		this.account = account;
	}

	private String Name;
	
	//new
	@ManyToOne
    @JoinColumn(name = "account_id") // Replace with the actual foreign key column name in your database
    private Accounts account;
	
	@OneToMany(mappedBy="timesheet")
	public Set<ProgramRun> programrun;
	
	/**
	 * @return the programrun
	 */
	public Set<ProgramRun> getProgramrun() {
		return programrun;
	}
	/**
	 * @param programrun the programrun to set
	 */
	public void setProgramrun(Set<ProgramRun> programrun) {
		this.programrun = programrun;
	}

	private String BankName;
	/**
	 * @return the name
	 */
	public String getName() {
		return Name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		Name = name;
	}
	private String AccountNo;

	
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the duration
	 */

	/**
	 * @return the bankName
	 */
	public String getBankName() {
		return BankName;
	}
	/**
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		BankName = bankName;
	}
	/**
	 * @return the accountNo
	 */
	public String getAccountNo() {
		return AccountNo;
		}
	/**
	 * @param accountNo the accountNo to set
	 */
	public void setAccountNo(String accountNo) {
		AccountNo = accountNo;
	}

	
	

}
