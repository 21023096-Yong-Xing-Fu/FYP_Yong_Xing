/**
 * 
 * I declare that this code was written by me, 21023327. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Student Name: Liu yuexiao
 * Student ID: 21023327
 * Class: E63C
 * Date created: 2023-May-24 2:58:46 pm 
 * 
 */

package e62c.yunke.ga02;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * @author 21023327
 *
 */
@Controller
public class CategoryController {

	@Autowired
	private CategoryRepository categoryRepository;

	@GetMapping("/category")
	public String viewCategory(Model model) {
		List<Categorys> listCategorys = categoryRepository.findAll();
		model.addAttribute("listCategorys", listCategorys);
		return "viewCategory";

	}

	// add
	@GetMapping("/category/add")
	public String addCategory(Model model) {
		model.addAttribute("categorys", new Categorys());
		return "addCategory";
	}

	@PostMapping("/category/save")
	public String saveCategory(@Valid Categorys categorys, BindingResult bindingResult) {
		if(bindingResult.hasErrors())
		{
			System.out.println(bindingResult.getFieldError());
			return "addCategory";
		}

		categoryRepository.save(categorys);
		return "redirect:/category";
	}
	
	//edit
	  @GetMapping("/category/edit/{id}")
	  public String editCategory(@PathVariable("id") Integer id, Model model) {

	    Categorys categorys = categoryRepository.getById(id);
	    model.addAttribute("categorys", categorys);

	    return "editCategory";
	  }

	  @PostMapping("/category/edit/{id}")
	  public String saveUpdatedCategory(@PathVariable("id") Integer id, Categorys categorys) {

	    categoryRepository.save(categorys);
	    return "redirect:/category";
	  }

	// delete

	@GetMapping("/category/delete/{id}")
	public String deleteCategory(@PathVariable("id") Integer id) {

		
		categoryRepository.deleteById(id);
	

		return "redirect:/category";
	}

}
