package e62c.yunke.ga02;

public class TimeClashException extends Exception {

    public TimeClashException(String message) {
        super(message);
    }
}
