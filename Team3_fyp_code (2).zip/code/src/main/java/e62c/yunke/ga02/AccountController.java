/**
 * I declare that this code was written by me, 21024433. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * Student Name: Ryan Pee
 * Student ID: 21024433
 * Class: E63C
 * Date created: 2023-May-01 7:58:11 pm 

 */
package e62c.yunke.ga02;

import java.io.FileWriter;
import java.io.IOException;
import org.springframework.mail.SimpleMailMessage;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

import java.util.UUID;

@Controller
public class AccountController {

	@Autowired
	private AccountRepository accountRepository;

	@Autowired
	private CategoryRepository categoryRepository;

	@Autowired
	private AccountService accountService;

	@Autowired
	private JavaMailSender javaMailSender;

	private String generateResetToken() {
		// Generate a random string or use a token generation library
		// For example, you can use UUID to generate a unique token
		return UUID.randomUUID().toString();
	}

	@GetMapping("/accounts")
	public String viewAccounts(Model model, Authentication authentication) {
		String userRole = authentication.getAuthorities().iterator().next().getAuthority();

		if (userRole.equals("ROLE_ADMIN")) {
			List<Accounts> listAccounts = accountRepository.findAll();
			model.addAttribute("listAccounts", listAccounts);
		} else if (userRole.equals("ROLE_TRAINER")) {
			// Retrieve the currently logged in trainer's account
			String username = authentication.getName();
			Accounts trainerAccount = accountRepository.findByUsername(username);
			model.addAttribute("listAccounts", trainerAccount);
			// model.addAttribute("listAccounts",
			// Collections.singletonList(trainerAccount));
		}

		return "view_accounts";
	}

	@GetMapping("/accounts/add")
	public String addAccount(Model model) {

//  List<Categorys> catList = categoryRepository.findAll(); 

//  model.addAttribute("catList", catList); 
		model.addAttribute("accounts", new Accounts());

		return "add_account";
	}

	@PostMapping("/accounts/save")
	public String saveAccount(@Valid Accounts accounts, BindingResult bindingResult, Model model,
			RedirectAttributes redirectAttribute) {

		if (bindingResult.hasErrors()) {

//			List<Categorys> catList = categoryRepository.findAll();
//			model.addAttribute("catList", catList);

			System.out.println(bindingResult.getFieldError());

			return "add_account";
		}

		if (accountService.isUsernameExists(accounts.getUsername())) {
			bindingResult.rejectValue("username", "error.username",
					"Username already exists! Please try another username.");
			return "add_account";
		}

		if (accountService.isEmailExists(accounts.getEmail())) {
			bindingResult.rejectValue("email", "error.email", "Email already exists! Please use a different email.");
			return "add_account";
		}

		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String encodedPassword = passwordEncoder.encode(accounts.getPassword());

		accounts.setPassword(encodedPassword);
		accounts.setRole("ROLE_TRAINER");

		accountRepository.save(accounts);

		redirectAttribute.addFlashAttribute("success", "Account registered!");

		return "redirect:/accounts";
	}

	@GetMapping("/accounts/edit/{id}")
	public String editAccount(@PathVariable("id") Integer id, Model model) {

		Accounts accounts = accountRepository.getById(id);

		model.addAttribute("accounts", accounts);

		return "edit_account";
	}

	@PostMapping("/accounts/edit/{id}")
	public String saveUpdatedAccount(@Valid Accounts accounts, BindingResult bindingResult,
			RedirectAttributes redirectAttribute) {

		if (bindingResult.hasErrors()) {
			return "edit_account";
		}

		if (accountService.isUsernameExists(accounts.getUsername())) {
			bindingResult.rejectValue("username", "error.username",
					"Username already exists! Please try another username.");
			return "add_account";
		}
		if (accountService.isEmailExists(accounts.getEmail())) {
			bindingResult.rejectValue("email", "error.email", "Email already exists! Please use a different email.");
			return "add_account";
		}

		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String encodedPassword = passwordEncoder.encode(accounts.getPassword());

		accounts.setPassword(encodedPassword);

		redirectAttribute.addFlashAttribute("success", "Account updated!");

		accountRepository.save(accounts);

		return "redirect:/accounts";
	}

	// delete item
	@GetMapping("/accounts/delete/{id}")
	public String deleteAccount(@PathVariable("id") Integer id) {

		accountRepository.deleteById(id);

		return "redirect:/accounts";
	}

	// forgot password
	@GetMapping("/forgot-password")
	public String showForgotPasswordForm() {
		return "forgot_password";
	}

	@PostMapping("/forgot-password")
	public String processForgotPasswordForm(@RequestParam("email") String email, Model model) {
		// Check if the email is in a valid format
		if (!isValidEmail(email)) {
			model.addAttribute("error", "Invalid email.");
			return "forgot_password";
		}

		// Retrieve the account associated with the provided email
		Accounts account = accountRepository.findByEmail(email);

		if (account == null) {
			// Account not found for the provided email
			model.addAttribute("error", "No account found for the provided email.");
			return "forgot_password";
		}

		// Generate a reset token
		String resetToken = generateResetToken();
		account.setResetToken(resetToken);
		accountRepository.save(account);

		// Send email
		// Toggle breakpoint anywhere below here before sendEmail function and run in
		// debug mode
		String subject = "Change Password!";
		String body = "Please click the link below to reset your password:\n"
				+ "Reset Password Link: http://localhost:8080/reset-password?token=" + resetToken + "\n"
				+ "If you did not request a password reset, please ignore this email.";
		String to = account.getEmail();
		sendEmail(to, subject, body);
		model.addAttribute("successMessage", "Password reset instructions have been sent to your email.");
		return "forgot_password";
	}

	public void sendEmail(String to, String subject, String body) {

		SimpleMailMessage msg = new SimpleMailMessage();
		msg.setTo(to);
		msg.setSubject(subject);
		msg.setText(body);

		System.out.println("Sending");
		javaMailSender.send(msg);
		System.out.println("Sent");
	}

	// Validate email format using regular expression
	private boolean isValidEmail(String email) {
		String emailRegex = "^[A-Za-z0-9+_.-]+@(.+)$";
		return email.matches(emailRegex);
	}

	// reset password
	// ...

	@GetMapping("/reset-password")
	public String showResetPasswordForm(@RequestParam("token") String resetToken, Model model) {
		// Find the account with the provided reset token
		Accounts account = accountRepository.findByResetToken(resetToken);

		// Check if the reset token is valid
		if (account == null) {
			model.addAttribute("error", "Invalid reset token.");
			return "reset_password";
		}

		// Pass the reset token to the form
		model.addAttribute("resetPasswordForm", new ResetPasswordForm(resetToken));
		return "reset_password";
	}

	@PostMapping("/reset-password")
	public String resetPassword(@Valid ResetPasswordForm resetPasswordForm, BindingResult bindingResult, Model model) {
		if (bindingResult.hasErrors()) {
			return "reset_password";
		}

		// Find the account with the provided reset token
		Accounts account = accountRepository.findByResetToken(resetPasswordForm.getResetToken());

		// Check if the reset token is valid
		if (account == null) {
			model.addAttribute("error", "Invalid reset token.");
			return "reset_password";
		}

		if (!resetPasswordForm.getNewPassword().equals(resetPasswordForm.getConfirmPassword())) {
			bindingResult.rejectValue("confirmPassword", "error.confirmPassword",
					"New Password and Confirm Password must match.");
			return "reset_password";
		}

		// Proceed with resetting the password
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String newPassword = passwordEncoder.encode(resetPasswordForm.getNewPassword());
		account.setPassword(newPassword);
		account.setResetToken(null); // Reset the reset token after password reset
		accountRepository.save(account);

		// Redirect the user to a success page or login page
		return "redirect:/login";
	}

	// Change password
	@GetMapping("/change-password")
	public String showChangePasswordForm(Model model) {
		model.addAttribute("changePasswordForm", new ChangePasswordForm());
		return "change_password";
	}

	@PostMapping("/change-password")
	public String changePassword(@Valid ChangePasswordForm changePasswordForm, BindingResult bindingResult,
			Model model) {
		if (bindingResult.hasErrors()) {
			return "change_password";
		}

		// Retrieve the currently logged in user's account
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String username = authentication.getName();
		Accounts account = accountRepository.findByUsername(username);

		// Retrieve the current password from the backend (e.g., from a database)
		String currentPassword = retrieveCurrentPassword(account.getUsername());

		// Verify if the entered current password matches the retrieved current password
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

		if (passwordEncoder.matches(changePasswordForm.getCurrentPassword(), currentPassword)) {
			// Verify if the new password matches the confirm new password
			if (!changePasswordForm.getNewPassword().equals(changePasswordForm.getConfirmPassword())) {
				bindingResult.rejectValue("confirmPassword", "error.confirmPassword",
						"New Password and Confirm Password must match.");
				return "change_password";
			}

			// Passwords match, proceed with changing the password
			String newPassword = passwordEncoder.encode(changePasswordForm.getNewPassword());
			account.setPassword(newPassword);
			accountRepository.save(account);
			return "login.html";
		} else {
			// Passwords don't match, display an error message
			model.addAttribute("errorMessage", "Current password is incorrect");
			return "change_password";
		}
	}

	// Example method to retrieve the current password from the backend (replace
	// with your own implementation)
	private String retrieveCurrentPassword(String username) {
		// Retrieve the current password for the account with the given accountId from
		// the backend (e.g., database)
		// Replace this with your code to retrieve the current password
		Accounts account = accountRepository.findByUsername(username);
		return account != null ? account.getPassword() : "Account not found";
	}

	// report
	@GetMapping("/accounts/report")
	public String generateReport(Model model) {
		List<Accounts> accounts = accountRepository.findAll();

		// Convert ProgramRun objects to ProgramRunJson objects
		List<AccountJson> accountJson = accounts.stream().map(AccountJson::new).collect(Collectors.toList());

		// Convert the list of ProgramRunJson objects to JSON using Gson
		Gson gson = new Gson();
		String accountJsonStr = gson.toJson(accountJson);
		model.addAttribute("accountJson", accountJsonStr);

		return "accountReport";
	}

}