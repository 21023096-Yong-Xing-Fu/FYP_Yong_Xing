/**
 * I declare that this code was written by me, 21024433. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * Student Name: Ryan Pee
 * Student ID: 21024433
 * Class: E63C
 * Date created: 2023-May-15 3:27:55 pm 

 */
package e62c.yunke.ga02;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public class AccountDetailsService implements UserDetailsService {

	@Autowired
	private AccountRepository accountRepository;

	@Override
	public AccountDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Accounts accounts = accountRepository.findByUsername(username);

		if (accounts == null) {
			throw new UsernameNotFoundException("Could not find user");
		}

		return new AccountDetails(accounts);
	}

}
