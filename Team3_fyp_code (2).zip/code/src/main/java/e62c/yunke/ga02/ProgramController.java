/**
 * 
 * I declare that this code was written by me, 21023327. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Student Name: Liu yuexiao
 * Student ID: 21023327
 * Class: E63C
 * Date created: 2023-May-01 8:27:57 pm 
 * 
 */

package e62c.yunke.ga02;

import java.io.IOException;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * @author 21023327
 *
 */
//@Controller
//public class ProgramController {
//	@Autowired
//	private ProgramRepository programRepository;
//	
//	@Autowired
//	private CategoryRepository categoryRepository;
//	
//	
//
//	@GetMapping("/program")
//	public String viewProgram(Model model) {
//		List<Programs> listPrograms = programRepository.findAll();
//		model.addAttribute("listPrograms", listPrograms);
//		return "viewProgram";
//	}
//
//	@GetMapping("/program/add")
//	public String addProgram(Model model) {
//		
//		List<Categorys> catList = categoryRepository.findAll(); // Assuming you have a repository for Category
//	    model.addAttribute("catList", catList);
//		
//		model.addAttribute("programs", new Programs());
//		return "addProgram";
//	}
//
//	@PostMapping("/program/save")
//	public String saveProgram(@Valid Programs programs, BindingResult bindingResult) {
//		if (bindingResult.hasErrors()) {
//			System.out.println(bindingResult.getFieldError());
//			return "addProgram";
//		}
//		programRepository.save(programs);
//
//		return "redirect:/program";
//	}
//
//	// edit
//	@GetMapping("/program/edit/{id}")
//	public String editProgram(@PathVariable("id") Integer id, Model model) {
//		
//		List<Categorys> catList = categoryRepository.findAll(); // Assuming you have a repository for Category
//	    model.addAttribute("catList", catList);
//		
//		Programs programs = programRepository.getById(id);
//		model.addAttribute("programs", programs);
//		return "editProgram";
//	}
//
//	@PostMapping("/program/edit/{id}")
//	public String saveUpdatedProgram(@PathVariable("id") Integer id, Programs programs) {
//		programRepository.save(programs);
//		return "redirect:/program";
//	}
//
//	// delete
//	@GetMapping("/program/delete/{id}")
//	public String deleteProgram(@PathVariable("id") Integer id) {
//		programRepository.deleteById(id);
//
//		return "redirect:/program";
//	}
//
//	@GetMapping(path = "/programs/category/{id}")
//	public String getProgramsbyCategory(@PathVariable Integer id, Model model) {
//
//		List<Programs> listPrograms = programRepository.findByCategory_Id(id);
//
//		model.addAttribute("listPrograms", listPrograms);
//		return "viewProgram";
//	}
//	
//	//report 

@Controller
public class ProgramController {
    private final ProgramRepository programRepository;
    private final CategoryRepository categoryRepository;
    private final AccountRepository accountRepository;
    private final JavaMailSender javaMailSender;

    @Autowired
    public ProgramController(ProgramRepository programRepository, CategoryRepository categoryRepository, AccountRepository accountRepository, JavaMailSender javaMailSender) {
        this.programRepository = programRepository;
        this.categoryRepository = categoryRepository;
        this.accountRepository = accountRepository;
        this.javaMailSender = javaMailSender;
    }

    @GetMapping("/program")
    public String viewProgram(Model model) {
        List<Programs> listPrograms = programRepository.findAll();
        model.addAttribute("listPrograms", listPrograms);
        return "viewProgram";
    }

    @GetMapping("/program/add")
    public String addProgram(Model model) {
        List<Categorys> catList = categoryRepository.findAll();
        model.addAttribute("catList", catList);
        model.addAttribute("programs", new Programs());
        return "addProgram";
    }

    @PostMapping("/program/save")
    public String saveProgram(@Valid Programs programs, BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            List<Categorys> catList = categoryRepository.findAll();
            model.addAttribute("catList", catList);
            return "addProgram";
        }

        int minAge = programs.getAgeGroupMin();
        int maxAge = programs.getAgeGroupMax();
        if (minAge >= maxAge) {
            bindingResult.rejectValue("ageGroupMax", "AgeGroup", "Maximum age must be greater than minimum age");
            List<Categorys> catList = categoryRepository.findAll();
            model.addAttribute("catList", catList);
            return "addProgram";
        }
        programRepository.save(programs);

        List<Accounts> signedUpUsers = accountRepository.findAll(); // Fetch signed-up users from the database
        sendEmailToSignedUpUsers(programs, signedUpUsers); // Send email to signed-up users

        return "redirect:/program";
    }

    private void sendEmailToSignedUpUsers(Programs program, List<Accounts> signedUpUsers) {
        for (Accounts user : signedUpUsers) {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(user.getEmail());
            message.setSubject("New Program Added");
            message.setText("Dear " + user.getName() + ",\n\nA new program has been added: " + program.getProgramName() +
                    "\n\nProgram Description: " + program.getDescription() + "\n\nAge Group: " +
                    program.getAgeGroupMin() + " - " + program.getAgeGroupMax());

            javaMailSender.send(message);
        }
    }

	@GetMapping("/program/edit/{id}")
	public String editProgram(@PathVariable("id") Integer id, Model model) {
		List<Categorys> catList = categoryRepository.findAll();
		model.addAttribute("catList", catList);
		Programs programs = programRepository.getById(id);
		model.addAttribute("programs", programs);
		return "editProgram";
	}

	@PostMapping("/program/edit/{id}")
	public String saveUpdatedProgram(@PathVariable("id") Integer id, Programs programs) {
		programRepository.save(programs);
		return "redirect:/program";
	}

	@GetMapping("/program/delete/{id}")
	public String deleteProgram(@PathVariable("id") Integer id) {
		programRepository.deleteById(id);
		return "redirect:/program";
	}

	@GetMapping(path = "/programs/category/{id}")
	public String getProgramsByCategory(@PathVariable Integer id, Model model) {
		List<Programs> listPrograms = programRepository.findByCategory_Id(id);
		model.addAttribute("listPrograms", listPrograms);
		return "viewProgram";
	}

	@GetMapping("/report/program")
	public String generateReport(Model model) {
		List<Programs> listPrograms = programRepository.findAll();
		model.addAttribute("listPrograms", listPrograms);
		return "ProgramReport";
	}

	@GetMapping("/program/charts")
	public ResponseEntity<String> getProgramCharts() {
		List<Programs> listPrograms = programRepository.findAll();

		JsonObject chartData = new JsonObject();
		JsonArray categoryLabels = new JsonArray();
		JsonArray categoryData = new JsonArray();
		JsonArray ageGroupLabels = new JsonArray();
		JsonArray ageGroupData = new JsonArray();

		Set<String> assignedColors = new HashSet<>();
		Set<String> ageGroupColors = new HashSet<>(); // New set for age group colors

		for (Programs program : listPrograms) {
			String category = program.getCategory().getName();
			int ageGroupMin = program.getAgeGroupMin();
	        int ageGroupMax = program.getAgeGroupMax();
	        String ageGroup = ageGroupMin + "-" + ageGroupMax;

			boolean categoryExists = false;
			for (int i = 0; i < categoryLabels.size(); i++) {
				if (categoryLabels.get(i).getAsString().equals(category)) {
					int count = categoryData.get(i).getAsInt();
					categoryData.set(i, new JsonPrimitive(count + 1)); // Convert integer to JsonElement
					categoryExists = true;
					break;
				}
			}

			if (!categoryExists) {
				categoryLabels.add(new JsonPrimitive(category));
				categoryData.add(new JsonPrimitive(1)); // Convert integer to JsonElement
			}

			boolean ageGroupExists = false;
			for (int i = 0; i < ageGroupLabels.size(); i++) {
				if (ageGroupLabels.get(i).getAsString().equals(ageGroup)) {
					int count = ageGroupData.get(i).getAsInt();
					ageGroupData.set(i, new JsonPrimitive(count + 1)); // Convert integer to JsonElement
					ageGroupExists = true;
					break;
				}
			}

			if (!ageGroupExists) {
				ageGroupLabels.add(new JsonPrimitive(ageGroup));
				ageGroupData.add(new JsonPrimitive(1)); // Convert integer to JsonElement
				String color = generateRandomColor(ageGroupColors); // Generate a color for the age group
				ageGroupColors.add(color); // Add the color to the set
			}

			String color = generateRandomColor(assignedColors);
			assignedColors.add(color);
		}

		chartData.add("categoryLabels", categoryLabels);
		chartData.add("categoryData", categoryData);
		chartData.add("ageGroupLabels", ageGroupLabels);
		chartData.add("ageGroupData", ageGroupData);

		// Calculate and add percentages
		JsonArray categoryPercentages = calculatePercentage(categoryData);
		JsonArray ageGroupPercentages = calculatePercentage(ageGroupData);

		chartData.add("categoryPercentages", categoryPercentages);
		chartData.add("ageGroupPercentages", ageGroupPercentages);

		// Assign colors to the categories
		JsonArray backgroundColors = new JsonArray();
		List<String> assignedColorsList = new ArrayList<>(assignedColors);
		for (int i = 0; i < categoryLabels.size(); i++) {
			backgroundColors.add(new JsonPrimitive(assignedColorsList.get(i)));
		}

		chartData.add("backgroundColor", backgroundColors);

		// Add ageGroupColors to the chartData
		JsonArray ageGroupColorsArray = new JsonArray();
		for (String color : ageGroupColors) {
			ageGroupColorsArray.add(new JsonPrimitive(color));
		}
		chartData.add("ageGroupColors", ageGroupColorsArray);

		return ResponseEntity.ok().body(new Gson().toJson(chartData));
	}

	// Helper method to calculate percentages
	private JsonArray calculatePercentage(JsonArray data) {
		JsonArray percentages = new JsonArray();
		int total = 0;
		for (int i = 0; i < data.size(); i++) {
			int count = data.get(i).getAsInt();
			total += count;
		}
		for (int i = 0; i < data.size(); i++) {
			int count = data.get(i).getAsInt();
			double percentage = (count / (double) total) * 100;
			percentages.add(new JsonPrimitive(Math.round(percentage) + "%"));
		}
		return percentages;
	}

	// Helper method to generate a random color
	private String generateRandomColor(Set<String> assignedColors) {
		Random random = new Random();
		String color;
		do {
			int r = random.nextInt(256);
			int g = random.nextInt(256);
			int b = random.nextInt(256);
			color = String.format("#%02x%02x%02x", r, g, b);
		} while (assignedColors.contains(color));
		return color;
	}
	
	
	

	
	
}

















