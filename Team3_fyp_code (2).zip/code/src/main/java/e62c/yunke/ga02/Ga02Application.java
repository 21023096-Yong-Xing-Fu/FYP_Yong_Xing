package e62c.yunke.ga02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ga02Application {

	public static void main(String[] args) {
		SpringApplication.run(Ga02Application.class, args);
	}

}
