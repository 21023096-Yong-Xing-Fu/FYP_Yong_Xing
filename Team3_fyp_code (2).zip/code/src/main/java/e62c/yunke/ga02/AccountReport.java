/**
 * I declare that this code was written by me, 21024433. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * Student Name: Ryan Pee
 * Student ID: 21024433
 * Class: E63C
 * Date created: 2023-Jul-31 7:31:44 pm 

 */
package e62c.yunke.ga02;

/**
 * @author 21024433
 *
 */

import java.util.List;

public class AccountReport {
    private int totalAccounts;
    private int totalMale;
    private int totalFemale;
    private int totalAdmins;
    private int totalTrainers;
    private List<Accounts> accountsList;

    public AccountReport(int totalAccounts, int totalMale, int totalFemale, int totalAdmins, int totalTrainers, List<Accounts> accountsList) {
        this.totalAccounts = totalAccounts;
        this.totalMale = totalMale;
        this.totalFemale = totalFemale;
        this.totalAdmins = totalAdmins;
        this.totalTrainers = totalTrainers;
        this.accountsList = accountsList;
    }

	public int getTotalAccounts() {
		return totalAccounts;
	}

	public void setTotalAccounts(int totalAccounts) {
		this.totalAccounts = totalAccounts;
	}

	public int getTotalMale() {
		return totalMale;
	}

	public void setTotalMale(int totalMale) {
		this.totalMale = totalMale;
	}

	public int getTotalFemale() {
		return totalFemale;
	}

	public void setTotalFemale(int totalFemale) {
		this.totalFemale = totalFemale;
	}

	public int getTotalAdmins() {
		return totalAdmins;
	}

	public void setTotalAdmins(int totalAdmins) {
		this.totalAdmins = totalAdmins;
	}

	public int getTotalTrainers() {
		return totalTrainers;
	}

	public void setTotalTrainers(int totalTrainers) {
		this.totalTrainers = totalTrainers;
	}

	public List<Accounts> getAccountsList() {
		return accountsList;
	}

	public void setAccountsList(List<Accounts> accountsList) {
		this.accountsList = accountsList;
	}

    
    
}

