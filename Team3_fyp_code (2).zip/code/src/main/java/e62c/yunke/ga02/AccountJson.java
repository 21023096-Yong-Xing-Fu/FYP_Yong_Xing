package e62c.yunke.ga02;

import java.util.List;

public class AccountJson {
	private int id;
	private String name;
	private String contact;
	private String email;
	private String username;
	private String password;
	private String gender;
	private String nric;
	private String rate;
	private String role;
	private String typeTrainer;
	private String status;
	private String resetToken;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getNric() {
		return nric;
	}

	public void setNric(String nric) {
		this.nric = nric;
	}

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getTypeTrainer() {
		return typeTrainer;
	}

	public void setTypeTrainer(String typeTrainer) {
		this.typeTrainer = typeTrainer;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getResetToken() {
		return resetToken;
	}

	public void setResetToken(String resetToken) {
		this.resetToken = resetToken;
	}

	// Constructor
	public AccountJson(Accounts account) {
		this.id = account.getId();
		this.name = account.getName();
		this.contact = account.getContact();
		this.email = account.getEmail();
		this.username = account.getUsername();
		this.password = account.getPassword();
		this.gender = account.getGender();
		this.nric = account.getNric();
		this.rate = account.getRate();
		this.role = account.getRole();
		this.typeTrainer = account.getTypeTrainer();
		this.status = account.getStatus();
		this.resetToken = account.getResetToken();
	}

	// Add other methods if needed
	// ...
}
