package e62c.yunke.ga02;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Length;

@Entity
public class Accounts {
	
	//29/6
	@OneToMany(mappedBy="account")
	private Set<ProgramRun> programRuns;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	//@NotNull
	@NotEmpty(message = "Account name cannot be empty!")
	private String name;

	//@NotNull
	@NotEmpty(message = "Contact number cannot be empty!")
	@Length(min = 8, max = 8, message = "Contact number must be at 8 digits long!")
	private String contact;

	//@NotNull
	@NotEmpty(message = "Email cannot be empty!")
	private String email;

	@NotNull
	@NotEmpty(message = "Username cannot be empty!")
	private String username;

	@NotNull
	@NotEmpty(message = "Password cannot be empty!")
	private String password;

	@NotNull
	@NotEmpty(message = "Gender cannot be empty!")
	private String gender;

	@NotNull
	@NotEmpty(message = "NRIC cannot be empty!")
	@Size(min = 9, max = 9, message = "NRIC must be 9 digits long!")
	private String nric;

	@NotNull
	@NotEmpty(message = "Rate cannot be empty!")
	private String rate;

	@NotNull
	@NotEmpty(message = "Type cannot be empty!")
	private String role;
	
	@NotNull
	@NotEmpty(message = "Type of Trainer Account cannot be empty!")
	private String typeTrainer;
	
	//@NotNull
	//@NotEmpty(message = "Role cannot be empty!")
	//private String type;

	@NotNull
	@NotEmpty(message = "Status cannot be empty!")
	private String status;
	
	private String resetToken;


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getNric() {
		return nric;
	}

	public void setNric(String nric) {
		this.nric = nric;
	}

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
	public String getTypeTrainer() {
		return typeTrainer;
	}

	public void setTypeTrainer(String typeTrainer) {
		this.typeTrainer = typeTrainer;
	}
	
	//public String getType() {
	//	return type;
	//}

//	public void setType(String type) {
	//	this.type = type;
	//}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getResetToken() {
		return resetToken;
	}

	public void setResetToken(String resetToken) {
		this.resetToken = resetToken;
	}
	
	
	

}
