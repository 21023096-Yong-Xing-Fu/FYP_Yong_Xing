/**
 * 
 * I declare that this code was written by me, 21023096. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Student Name: Yong Xing Fu
 * Student ID: 21023096
 * Class: E63C
 * Date created: 2023-May-01 8:01:27 pm 
 * 
 */


package e62c.yunke.ga02;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TimeSheetRepository extends JpaRepository<TimeSheet, Integer>{

	public List<TimeSheet> findByAccount(Accounts account);
	List<TimeSheet> findAllByAccountUsername(String username);
	/**
	 * @param username
	 * @return
	 */
	//public List<TimeSheet> getTimesheetDataByUsername(String username);
}

