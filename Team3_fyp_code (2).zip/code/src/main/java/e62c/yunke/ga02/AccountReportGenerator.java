package e62c.yunke.ga02;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class AccountReportGenerator {

	public static void generateCSVReportWithStatistics(List<Accounts> accountsList, String filePath) {
		try (FileWriter writer = new FileWriter(filePath)) {
			// Write the CSV header
			writer.write("ID,Username,Email,Role,Gender\n");

			int maleCount = 0;	
			int femaleCount = 0;
			int adminCount = 0; // New variable for counting admins
			int trainerCount = 0; // New variable for counting trainers

			// Write account details and update gender, admin, and trainer counts
			for (Accounts account : accountsList) {
				String gender = account.getGender();
				String role = account.getRole();

				if ("MALE".equals(gender)) {
					maleCount++;
				} else if ("FEMALE".equals(gender)) {
					femaleCount++;
				}

				if ("ROLE_ADMIN".equals(role)) {
					adminCount++;
				} else if ("ROLE_TRAINER".equals(role)) {
					trainerCount++;
				}

				writer.write(account.getId() + "," + account.getUsername() + "," + account.getEmail() + "," + role + ","
						+ gender + "\n");
			}

			// Write gender, admin, and trainer statistics to the report
			writer.write("\n");
			writer.write(",,Total Male Members," + maleCount + "\n");
			writer.write(",,Total Female Members," + femaleCount + "\n");
			writer.write(",,Total Admins," + adminCount + "\n"); // Adding the admin count
			writer.write(",,Total Trainers," + trainerCount + "\n"); // Adding the trainer count

			System.out.println("CSV report with statistics generated successfully at: " + filePath);
		} catch (IOException e) {
			System.out.println("Error while generating CSV report: " + e.getMessage());
		}
	}

}
