/**
 * 
 * I declare that this code was written by me, 21023327. 
 * I will not copy or allow others to copy my code. 
 * I understand that copying code is considered as plagiarism.
 * 
 * Student Name: Liu yuexiao
 * Student ID: 21023327
 * Class: E63C
 * Date created: 2023-May-24 5:10:09 am 
 * 
 */

package e62c.yunke.ga02;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


/**
 * @author 21023327
 *
 */
@Entity
public class Categorys {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @NotNull
    @NotEmpty(message = "Category name cannot be empty!")
    @Size(min = 3, max = 15, message = "Category length must be between 3 and 15 characters!")
    private String name;

    @NotNull(message = "Category cannot be empty!")
    @OneToMany(mappedBy = "category")
    private Set<Programs> programs = new HashSet<>(); // Initialize the "programs" field with an empty set

 // Getter and setter for "programs" field
    public Set<Programs> getPrograms() {
        return programs;
    }

    public void setPrograms(Set<Programs> programs) {
        this.programs = programs;
    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	
	

}
