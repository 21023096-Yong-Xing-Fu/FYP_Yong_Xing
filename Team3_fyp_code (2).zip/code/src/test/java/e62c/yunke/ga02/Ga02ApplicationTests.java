package e62c.yunke.ga02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ga02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
